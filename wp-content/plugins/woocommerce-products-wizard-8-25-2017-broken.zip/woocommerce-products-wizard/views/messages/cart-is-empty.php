<?php
if (!defined('ABSPATH')) {
    exit();
}
?>
<div class="alert alert-info">
    <?php _e('Your cart is empty', 'woocommerce-products-wizard'); ?>
</div>
