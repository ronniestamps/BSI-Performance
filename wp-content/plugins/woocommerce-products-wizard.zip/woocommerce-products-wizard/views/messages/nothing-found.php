<?php
if (!defined('ABSPATH')) {
    exit();
}
?>
<div class="alert alert-info">
    <?php _e('No results for your choice', 'woocommerce-products-wizard'); ?>
</div>
